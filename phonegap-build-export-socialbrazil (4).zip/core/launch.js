require.config({

    baseUrl: 'vendor',

    waitSeconds: 10,

    paths: {
        core: '../core',
		lang: '../lang',
		addons: '../addons',
        root: '..'
    },

    shim: {
        'backbone': {
            deps: ['underscore', 'jquery'],
            exports: 'Backbone'
        },
        'underscore': {
            exports: '_'
        }
    }
});

require(['root/config'],function(Config){

	//If Progressive Web App, activate service worker to cache app source files:
	if ( Config.app_type === 'pwa' && 'serviceWorker' in navigator ) {
		navigator.serviceWorker
				.register( Config.app_path +'service-worker-cache.js' )
				.then( function () {
					console.log( '[WP-AppKit Service Worker] Registered' );
				} );
        
	}

	var dynamic_paths = {
		theme: '../themes/'+ Config.theme
	};

	require.config({
	    paths: dynamic_paths
	});

	require(['jquery', 'underscore', 'core/addons-internal', 'core/app-utils', 'core/app', 'core/router', 'core/region-manager', 'core/stats', 'core/phonegap/utils','core/lib/hooks'],
			function ($, _, Addons, Utils, App, Router, RegionManager, Stats, PhoneGap, Hooks) {

			var launch = function() {
				
				require(Addons.getJs('init','before'),function(){
					// Initialize application before using it
					App.initialize( function() {

						RegionManager.buildHead(function(){

							RegionManager.buildLayout(function(){

								RegionManager.buildHeader(function(){

                                    App.router = new Router();

									require(Addons.getJs('theme','before'),function(){
										require(['theme/js/functions'],function(){
											
                                            /**
                                             * Intercept navigation inside the app to trigger Backbone router navigation
                                             * instead of browser page refresh. 
                                             */
                                            RegionManager.handleNavigationInterception();
                                            
											/**
											 * Templates that are preloaded by default for before perf.
											 * Note: we can't require 'page' template here as it is not required in themes.
											 * But when implementing a theme with a 'page' template, it is recommended to 
											 * preload it with the following 'preloaded-templates'.
											 */
											var preloaded_templates = ['single','archive'];
											
											/**
											 * Define templates that are preloaded so that we don't have any delay
											 * when requiring them dynamically.
											 * For example use this filter to preload the 'page' template if you implement one in your theme.
											 */
											preloaded_templates = Hooks.applyFilters('preloaded-templates',preloaded_templates,[]);
											
											//Build 'text!path/template.html' dependencies from preloaded templates:
											preloaded_templates = _.map( preloaded_templates, function( template ) {
												if( template.indexOf( '/' ) === -1 ) {
													template = 'theme/'+ template;
												}
												return 'text!'+ template +'.html';
											} );
											
											require(preloaded_templates,function(){
											
												require(Addons.getJs('theme','after'),
													function(){
														App.sync(
															function( deferred ){
																RegionManager.buildMenu(function(){ //Menu items are loaded by App.sync

																	Stats.updateVersion();
																	Stats.incrementCountOpen();
																	Stats.incrementLastOpenTime();

																	if( Config.debug_mode == 'on' ){
																		Utils.log( 'App version : ', Stats.getVersionDiff() );
																		Utils.log( 'App opening  count : ', Stats.getCountOpen() );
																		Utils.log( 'Last app opening  was on ', Stats.getLastOpenDate() );
																	}

																	App.launchRouting();

                                                                    if ( deferred ) {
                                                                        deferred.resolve( { ok: true, message: '', data: {} } );
                                                                    }

																	App.triggerInfo('app-launched'); //triggers info:app-ready, info:app-first-la