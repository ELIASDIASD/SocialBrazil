define( function ( require ) {

	"use strict";

	return {
		app_slug : 'socialbrazil',
		wp_ws_url : 'http://socialbrazil.ga/wp-appkit-api/socialbrazil',
		wp_url : 'http://socialbrazil.ga',
		theme : 'q-android',
		version : '1.0',
		app_type : 'phonegap-build',
		app_title : 'SocialBrazil',
		app_platform : 'android',
		app_path: '',
		gmt_offset : -3,
		debug_mode : 'off',
		auth_key : '-wBlwO4o;bx[u1_D%:U4bZP4%iBGE4[B5(wjYK0/q0Z|M+n01A5_DPn+>*%(g-Mz',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
